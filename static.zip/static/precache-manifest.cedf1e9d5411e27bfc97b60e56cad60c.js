self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d47bf7445562d2a27de1a5345cfe8f7e",
    "url": "/static/index.html"
  },
  {
    "revision": "74228da97ccfe1e413d9",
    "url": "/static/static/css/main.5e4e9510.chunk.css"
  },
  {
    "revision": "c03013779a4e465ab2b6",
    "url": "/static/static/js/2.05b32077.chunk.js"
  },
  {
    "revision": "74228da97ccfe1e413d9",
    "url": "/static/static/js/main.5a76f356.chunk.js"
  },
  {
    "revision": "a4c582f53ae9833779e0",
    "url": "/static/static/js/runtime-main.74c8f0f6.js"
  }
]);